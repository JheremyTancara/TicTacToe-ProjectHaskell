module Main (main) where

main :: IO ()
main = do
  putStrLn "tic tac toe"
